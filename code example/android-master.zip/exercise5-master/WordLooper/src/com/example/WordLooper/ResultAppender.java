package com.example.WordLooper;


public interface ResultAppender
{
    public void showResult(String result);
}
